create or replace VIEW ma_master_order_ids AS   
/****************************************************************
*Created by : Luciano Hb  10-31-17
*
*****************************************************************/       
    select DISTINCT
           o.master_po_no order_no
      from ma_v_ordhead o
      where o.status     = 'A'
    UNION ALL
      select DISTINCT
             sd.master_order_no order_no
         from ma_stg_order_drops sd,
              ma_stg_order so
         where so.status  != 'A'
               AND sd.master_order_no = so.master_order_no;
       
create or replace view ma_order_ids as
/****************************************************************
*Altered by : Luciano Hb  10-31-17
*
*****************************************************************/       
    select o.order_no
      from ma_v_ordhead o
      where o.status     = 'A'
    UNION ALL
      select sd.order_no
        from ma_stg_order_drops sd,
             ma_stg_order so
        where so.status  != 'A'
              AND sd.master_order_no = so.master_order_no;
