/*
   altera��o tabela para testes .. --- 
*/

select  * FROM repl_results r  , -- where item = 200106604
         ma_v_item_master im
   WHERE r.item = im.item
   
update repl_results set item = 200181904
       where item = 200106604
  

select  * FROM  repl_results

delete repl_results where rownum > 4
     
select * from    ma_v_item_master
