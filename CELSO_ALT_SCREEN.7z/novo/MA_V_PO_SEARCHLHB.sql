CREATE OR REPLACE VIEW MA_V_PO_SEARCHLHB AS
SELECT tbl.master_order_no master_order_no,
         tbl.order_no order_no,
         tbl.item option_id,
         tbl.item_desc item_desc,
         tbl.item_status_desc item_status_desc,
         tbl.status status,
         tbl.status_desc status_desc,
         tbl.supplier supplier,
         tbl.supplier_reference supplier_reference,
         tbl.supp_desc supp_desc,
         tbl.expected_delivery_date expected_delivery_date,
         tbl.created_by created_by,
         tbl.fc fc,
         tbl.po_type po_type,
         tbl.po_source po_source,
         tbl.handover_date handover_date,
         tbl.product_group product_group,
         tbl.product_group_desc product_group_desc,
         tbl.product_hierarchy product_hierarchy,
         tbl.category category,
         tbl.category_desc category_desc,
         tbl.sub_category sub_category,
         tbl.sub_category_desc sub_category_desc,
         tbl.class_key class_key,
         tbl.subclass_key subclass_key,
         tbl.business_model business_model,
         tbl.business_model_name,
         tbl.buying_group buying_group,
         tbl.buying_group_name,
         tbl.buying_group_key,
         tbl.buying_subgroup buying_subgroup,
         tbl.buying_subgroup_name,
         tbl.buying_subgroup_key,
         tbl.buying_set,
         tbl.buying_set_name,
         tbl.buying_set_key,
         tbl.factory
    FROM (SELECT ord.master_order_no master_order_no,
                 ord.order_no order_no,
                 ord.item,
                 i.item_desc item_desc,
                 (select code_desc
                    from ma_v_code_detail
                   where code_type = 'MAIS'
                     and code      = i.status) item_status_desc,
                 ord.status status,
                 (select code_desc
                    from ma_v_code_detail
                   where code_type = 'ORST'
                     and code      = ord.status) status_desc,
                 ord.supplier supplier,
                 ord.supplier_reference,
                 sup.sup_name supp_desc,
                 ord.expected_delivery_date,
                 ord.created_by,
                 ord.fc,
                 ord.po_type,
                 ord.po_source,
                 ord.handover_date,
                 i.dept product_group,
                 d.dept_name product_group_desc,
                 (i.dept||' / '||i.class||' / '||i.subclass) product_hierarchy,
                 i.class category,
                 c.class_name category_desc,
                 i.subclass sub_category,
                 s.sub_name sub_category_desc,
                 c.class_key class_key,
                 s.subclass_key subclass_key,
                 mb.business_model,
                 mb.buying_group,
                 mb.buying_subgroup,
                 mb.buying_set,
                 mb.business_model_name,
                 mb.buying_group_name,
                 mb.buying_subgroup_name,
                 mb.buying_set_name,
                 buying_group_key,
                 buying_subgroup_key,
                 buying_set_key,
                 factory
            FROM ma_v_sups sup,
                 ma_v_item_master i,
                 ma_v_dept d,
                 ma_v_class c,
                 ma_v_subclass s,
                 ma_v_buyerarchy mb,
                 (SELECT o.master_order_no,
                         dd.order_no,
                         oo.option_id item,
                         o.status status,
                         o.supplier supplier,
                         isup.supplier_reference,
                         dd.first_dest_date expected_delivery_date,
                         o.create_id created_by,
                         idist.first_dest fc,
                         idist.po_type po_type,
                         NULL po_source,
                         idist.handover_date handover_date,
                         oo.factory
                    FROM ma_stg_order o,
                         ma_stg_order_option oo,
                         ma_stg_order_item_dist idist,
                         ma_stg_order_drops_detail dd,
                         ma_stg_item_sup isup
                   WHERE oo.master_order_no     = o.master_order_no
                     AND oo.master_order_no     = idist.master_order_no(+)
                     AND oo.option_id           = idist.option_id(+)
                     AND idist.master_order_no  = dd.master_order_no(+)
                     AND idist.id_seq           = dd.seq_no(+)
                     /*AND idist.option_id        = dd.option_id(+)
                     AND idist.first_dest       = dd.first_dest(+)
                     AND idist.final_dest       = dd.final_dest(+)*/
                     AND o.status               IN ('S','W')
                     and oo.option_id           = isup.item(+)
                     and o.supplier             = isup.supplier(+)
                  UNION ALL
                  SELECT DISTINCT
                         oh.master_po_no,
                         oh.order_no,
                         im.item_parent item,
                         oh.status,
                         oh.supplier,
                         isup.vpn supplier_reference,
                         oh.not_after_date,
                         oh.create_id,
                         ol.location,
                         oh.po_type,
                         NULL po_source,
                         oh.pickup_date,
                         oh.factory
                    FROM ordhead oh,
                         ordloc  ol,
                         ma_v_item_master im,
                         ma_v_item_supplier isup
                   WHERE oh.order_no = ol.order_no
                     AND oh.status   = 'A'
                     AND ol.item     = im.item
                     and ol.item     = isup.item
                     and oh.supplier = isup.supplier
               ) ord
         WHERE ord.supplier = sup.supplier
           AND ord.item     = i.item (+)
           AND i.dept       = d.dept
           AND i.dept       = c.dept
           AND i.class      = c.class
           AND i.dept       = s.dept
           AND i.class      = s.class
           AND i.subclass   = s.subclass
           AND mb.item      = i.item) tbl;
