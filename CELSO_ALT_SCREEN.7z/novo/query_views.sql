/*select *
                                  from MA_V_REPLENISHMENTLHB p
                                 where 1 = 1
                                   and p.buying_group_key = 00140001
                                   and p.business_model = 14                                                                
                          --********* and trunc(p.handover_date) = trunc(to_date('','DD-MM-YYYY')
                                 and p.status 
                                 and p.option_id = 200181865
                        and p.supplier = TO_NUMBER(b.bv_supplier)
                        */
                        PoReplenSearchLhbObj
                        
 select * from                        
     MA_V_REPLENISHMENTLHB                   
 select *
     from  MA_V_PLANNINGLHB  p 
     where 1 = 1
              and p.rec_source = 'U'
             and p.upload_id = 1
           -- and p.supplier = 1400
            --and trunc(p.handover_date) = trunc(to_date('22-11-2017','DD-MM-YYYY'))
           --and p.option_id = 1
           and p.status = 'A'
                    
   select * from        MA_UPLOAD_IDS              
ma_v_po_searchlhb    

select DISTINCT business_obj_id as upload_id from ma_stg_upload_process_line_ids where business_obj_type = 'ORDER_REC';
select * from ma_stg_upload_process_line_ids where business_obj_type = 'ORDER_REC';

select rowid, stg.* from MA_ORDER_REC_HEAD_STG stg                   
