--select * from MA_V_PO_SEARCHLHB
create type PoSearchLhbTbl 

MA_V_PLANNINGLHB

MA_V_REPLENISHMENT


select * from MA_ORDER_REC_HEAD_STG

select DISTINCT business_obj_id as ORDER_REC_NO 
    from ma_stg_upload_process_line_ids where business_obj_type = 'ORDER_REC';
    

MA_V_PO_SEARCHLHB

MA_V_REPLENISHMENT
drop type PoSearchLhbTbl
CREATE OR REPLACE TYPE PoSearchLhbTbl AS TABLE OF PoSearchLhbObj
 select 
                                                                  master_order_no,
                                                                  order_no,
                                                                  option_id,
                                                                  item_desc,
                                                                  item_status_desc,
                                                                  status,
                                                                  status_desc,
                                                                  supplier,                                                                  
                                                                 -- supplier_reference,
                                                                  supp_desc,
                                                                  expected_delivery_date,
                                                                  created_by,
                                                                --  create_datetime,
                                                                  fc,
                                                                  po_type,
                                                                  po_source,
                                                                  handover_date,
                                                                  handover_date + mso.handover_days,
                                                                  product_group,
                                                                  product_group_desc,
                                                                  category,
                                                                  category_desc,
                                                                  sub_category,
                                                                  sub_category_desc,
                                                                  class_key,
                                                                  subclass_key,
                                                                  business_model,
                                                                  business_model_name,
                                                                  buying_group,
                                                                  buying_group_name,
                                                                  buying_group_key,
                                                                  buying_subgroup,
                                                                  buying_subgroup_name,
                                                                  buying_subgroup_key,
                                                                  buying_set,
                                                                  buying_set_name,
                                                                  buying_set_key,
                                                                  factory,
                                                                  null
                                                                  
                         from MA_V_PO_SEARCHLHB p,
                              --t_binds b,
                              ma_system_options mso
